# usage . comare.sh filename.cc
diff $1 /Users/ttumuon/hep/g4/g4user/MuonSC8/rp/v5/sim/include/$1
