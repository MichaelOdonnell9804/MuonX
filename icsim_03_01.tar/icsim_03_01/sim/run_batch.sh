#
./exampleB4a  -b batch_run_C0RAA_01.mac -numberOfEvents 1000 -runNumber 987 -runSeq 99
# ./exampleB4a  -b batch_run_C0RRR_01.mac -numberOfEvents 1000 -runNumber 987 -runSeq 99
# ./exampleB4a  -b batch_run_C1RAA_01.mac -numberOfEvents 1000 -runNumber 987 -runSeq 99
# ./exampleB4a  -b batch_run_C1RRR_01.mac -numberOfEvents 1000 -runNumber 987 -runSeq 99
# ./exampleB4a  -b batch_run_C2RAA_01.mac -numberOfEvents 1000 -runNumber 987 -runSeq 99
# ./exampleB4a  -b batch_run_C2RRR_01.mac -numberOfEvents 1000 -runNumber 987 -runSeq 99
# ./exampleB4a  -b batch_run_C3RAA_01.mac -numberOfEvents 1000 -runNumber 987 -runSeq 99
# ./exampleB4a  -b batch_run_C3RRR_01.mac -numberOfEvents 1000 -runNumber 987 -runSeq 99
