# usage . comare.sh filename.cc
diff $1 /Users/ttumuon/hep/g4/g4user/MuonSC8/rp/v4_og/sim/src/$1
